# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2022 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

class UserRatesCollector
  include Redmine::I18n

  def initialize(user, date = User.current.today)
    @user = user
    @today = date
    start_of_week = Setting.start_of_week.blank? ? (l(:general_first_day_of_week).to_i)%7 + 1 : Setting.start_of_week.to_i
    start_day = Date::DAYS_INTO_WEEK.key(start_of_week)
    @beginning_of_week = @today.beginning_of_week(start_day)
    @rates_by_days = rates_by_days(@user.rates.cost_rates, @today.beginning_of_month.ago(1.month).to_date, @today)
  end

  def default_cost_rate
    @default_cost_rate ||= UserRate.cost_rate_for(@user, @today)
  end

  def default_bill_rate
    @default_bill_rate ||= UserRate.bill_rate_for(@user, @today)
  end

  def weekly_cost
    @weekly_cost ||= calculate_cost(@beginning_of_week, @today)
  end

  def previous_weekly_cost
    @previous_weekly_cost ||= calculate_cost(@beginning_of_week.ago(7.days).to_date, @today.ago(7.days).to_date)
  end

  def monthly_cost
    @monthly_cost ||= calculate_cost(@today.beginning_of_month, @today)
  end

  def previous_monthly_cost
    @previous_monthly_cost ||= calculate_cost(@today.beginning_of_month.ago(1.month).to_date, @today.ago(1.month).to_date)
  end

  private

  def calculate_cost(from, to)
    @user.time_entries.where('spent_on BETWEEN ? AND ?', from, to).inject(0) do |sum, time_entry|
      rate = cost_rate_by(time_entry.spent_on, time_entry.project_id)
      return unless rate # Return nil, because it is not possible to calculate the cost
      sum + (time_entry.hours * rate)
    end
  end

  def cost_rate_by(date, project)
    @rates_by_days[date][project] || @rates_by_days[date][nil] # nil is a key for default rate on date
  end

  def rates_by_days(rates, from, to)
    (from..to).inject({}) do |hash, date|
      rates_by_projects = UserRate.current_rates(rates, date).group_by(&:project_id)
      rates_by_projects.each { |project_id, rates| rates_by_projects[project_id] = rates.first.rate }
      hash[date] = rates_by_projects
      hash
    end
  end
end
