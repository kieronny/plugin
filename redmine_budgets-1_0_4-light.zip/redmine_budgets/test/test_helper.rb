# encoding: utf-8
#
# This file is a part of Redmin Budgets (redmine_budgets) plugin,
# Filse storage plugin for redmine
#
# Copyright (C) 2011-2022 RedmineUP
# http://www.redmineup.com/
#
# redmine_budgets is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_budgets is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_budgets.  If not, see <http://www.gnu.org/licenses/>.

require File.expand_path(File.dirname(__FILE__) + '/../../../test/test_helper')

def compatible_request(type, action, parameters = {})
  Rails.version < '5.1' ? send(type, action, parameters) : send(type, action, params: parameters)
end

def compatible_xhr_request(type, action, parameters = {})
  Rails.version < '5.1' ? xhr(type, action, parameters) : send(type, action, params: parameters, xhr: true)
end

def compatible_api_request(type, action, parameters = {}, headers = {})
  return send(type, action, :params => parameters, :headers => headers) if Redmine::VERSION.to_s >= '3.4'
  send(type, action, parameters, headers)
end

def redmine_budgets_fixtures_directory
  Redmine::Plugin.find(:redmine_budgets).directory + '/test/fixtures/'
end

def fixtures_class
  ActiveRecord::VERSION::MAJOR >= 4 ? ActiveRecord::FixtureSet : ActiveRecord::Fixtures
end

def create_fixtures(fixtures_directory, table_names, class_names = {})
  fixtures_class.create_fixtures(fixtures_directory, table_names, class_names)
end

def with_budgets_settings(options, &block)
  saved_settings = options.keys.inject({}) do |h, k|
    h[k] = case RedmineBudgets.settings[k]
           when Symbol, false, true, nil
             RedmineBudgets.settings[k]
           else
             RedmineBudgets.settings[k].dup
           end
    h
  end
  options.each { |k, v| RedmineBudgets.settings[k] = v }
  yield
ensure
  saved_settings.each { |k, v| RedmineBudgets.settings[k] = v } if saved_settings
end

def set_billing_settings_for(object, settings = {})
  object.billing_settings.settings = settings
  object.billing_settings.save
end

def check_attributes_for(object, expected_attributes = {})
  expected_attributes.each do |attr, value|
    assert value == object.send(attr), "#{object.class}##{object.id} '#{attr}' should be #{value}, but is #{object.send(attr)}"
  end
end
